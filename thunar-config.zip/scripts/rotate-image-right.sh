#!/bin/bash
for FILE in $1
do
    convert $FILE -rotate 90 $FILE
done
