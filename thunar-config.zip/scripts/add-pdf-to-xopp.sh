#!/bin/bash
for FILE in $F
do
    TYPE=$(echo $FILE | grep -P -o ".*\K\..*")
    if [[ $TYPE == .xopp ]]
    then
        TARGET=$(basename $FILE)
        TARGET+=".bg.pdf"
    else
        SOURCES+=$FILE
        SOURCES+=" "
    fi
done
pdfunite $TARGET $SOURCES .pdfunite-tmp.pdf
mv .pdfunite-tmp.pdf $TARGET
