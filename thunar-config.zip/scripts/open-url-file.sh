#!/bin/bash
for FILE in $1
do
    URL=$(cat $FILE | grep -P -o "URL=\K\S*")
    xdg-open $URL
done


