#!/bin/bash
for FILE in $1
do
    TARGET=$(basename $FILE .png)
    TARGET+=".jpeg"
    convert $FILE -quality 75 $TARGET
done
