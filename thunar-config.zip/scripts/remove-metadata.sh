#!/bin/bash
for FILE in $1
do
    mat2 --inplace --lightweight $FILE
done
