#!/bin/bash
for FILE in $F
do
    mat2 --inplace --lightweight $FILE
done
