const Applet = imports.ui.applet;
const Main = imports.ui.main;
const Clutter = imports.gi.Clutter;

function MyApplet(orientation, panelHeight, instanceId) {
    this._init(orientation, panelHeight, instanceId);
}

MyApplet.prototype = {
    __proto__: Applet.IconApplet.prototype,

    _init: function (orientation, panelHeight, instanceId) {
        Applet.IconApplet.prototype._init.call(this, orientation, panelHeight, instanceId);
        this.effect = new Clutter.DesaturateEffect();
        this.set_applet_icon_symbolic_name("applications-graphics");
        this.set_applet_tooltip(_("Click to desaturate Cinnamon to grayscale."));
    },

    on_applet_clicked: function () {
        if (Main.uiGroup.has_effects(this.effect)) {
            Main.uiGroup.remove_effect(this.effect);
        } else {
            Main.uiGroup.add_effect(this.effect);
        }
    }
};

function main(metadata, orientation, panelHeight, instanceId) {
    return new MyApplet(orientation, panelHeight, instanceId);
}
