const Applet = imports.ui.applet;
const Main = imports.ui.main;
const Clutter = imports.gi.Clutter;
const Settings = imports.ui.settings;

function MyApplet(orientation, panel_height, instance_id) {
    this._init(orientation, panel_height, instance_id);
}

MyApplet.prototype = {
    __proto__: Applet.IconApplet.prototype,

    _init: function (orientation, panel_height, instance_id) {
        Applet.IconApplet.prototype._init.call(this, orientation, panel_height, instance_id);
        this.set_applet_icon_symbolic_name("applications-graphics");
        this.set_applet_tooltip("Toggle desaturation");
        this.effect = new Clutter.DesaturateEffect();
        this.settings = new Settings.AppletSettings(this, "desaturate-cinnamon@locxter", this.instance_id);
        this.settings.bindProperty(Settings.BindingDirection.IN, "desaturate-on-startup", "desaturate_on_startup", null, null);
        if (this.desaturate_on_startup) {
            Main.uiGroup.add_effect(this.effect);
        }

    },

    on_applet_clicked: function () {
        if (Main.uiGroup.has_effects(this.effect)) {
            Main.uiGroup.remove_effect(this.effect);
        } else {
            Main.uiGroup.add_effect(this.effect);
        }
    }
};

function main(metadata, orientation, panel_height, instance_id) {
    return new MyApplet(orientation, panel_height, instance_id);
}
