#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    TARGET=$(basename $FILE .png)
    TARGET+=".jpeg"
    convert $FILE -quality 75 $TARGET
done
