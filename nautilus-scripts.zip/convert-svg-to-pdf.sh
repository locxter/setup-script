#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    TARGET=$(basename $FILE .svg)
    TARGET+=".pdf"
    cat $FILE | inkscape --pipe --export-filename=$TARGET
done
