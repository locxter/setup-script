#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    mat2 --inplace --lightweight $FILE
done
