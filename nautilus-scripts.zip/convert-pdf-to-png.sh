#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    PAGES=$(pdfinfo $FILE | grep -P -o "Pages:\s*\K\d+")
    TARGET=$(basename $FILE .pdf)
    if [[ $PAGES == 1 ]]
    then
        pdftoppm -singlefile -png $FILE $TARGET
    else
        pdftoppm -png $FILE $TARGET
    fi
done
