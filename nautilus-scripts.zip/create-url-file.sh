#!/bin/bash
URL=$(zenity --entry --text="Enter URL" --entry-text="https://")
FILE=$(zenity --entry --text="Enter filename" --entry-text="link")
tee $FILE.url << EOF
[InternetShortcut]
URL=$URL
EOF
