#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    TARGET=$(basename $FILE .jpg)
    TARGET=$(basename $TARGET .jpeg)
    TARGET+=".png"
    convert $FILE -quality 75 $TARGET
done
