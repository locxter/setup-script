#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    convert $FILE -rotate -90 $FILE
done
