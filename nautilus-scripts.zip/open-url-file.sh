#!/bin/bash
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    URL=$(cat $FILE | grep -P -o "URL=\K\S*")
    xdg-open $URL
done


