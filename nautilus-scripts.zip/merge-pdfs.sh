#!/bin/bash
I=0
for FILE in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS
do
    if (( $I == 0 ))
    then 
        TARGET=$(basename $FILE .pdf)
        TARGET+="-merged.pdf"
    fi
    SOURCES+=$FILE
    SOURCES+=" "
    (( I++ ))
done
pdfunite $SOURCES $TARGET
